## TradeUI

A basic auction house plugin for PocketMine-MP using modal forms. <br/>
No permissions required, just configure messages as desired.<br/><br>
Commands:
+ `/ah`: main auction house command, an ui will ask you to choose between `buy` and `sell`.
+ `/cart`: when your inventory was full and you couldn't buy an item, make space and use 
this command to get to the last item you looked at.
+ `/myoffers`: an ui with a list of items you added to the auction house will appear, 
you can remove items from there.